<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Application error</title>
    </head>
    <body>
        <h1><?php print htmlentities($title) ?></h1>
        <p>
            <?php print htmlentities($message) ?>
        </p>
    </body>
</html>
