<?php

require_once 'controller/ContactsController.php';

$controller = new ContactsController();

$controller->handleRequest();

?>
